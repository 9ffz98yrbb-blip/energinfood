# EnergiFood V1 — iPhone
Cette version est une web-app mobile : écran d'accueil, objectifs, calories, macros, journal, ajout de repas et capture photo.
Les données sont stockées localement dans le navigateur de l'iPhone.
La reconnaissance IA des repas par photo n'est pas encore branchée : la caméra est prête comme point d'entrée.
